exports.webName = 'Cryptovilles AI Algorithm Trading System'
exports.webShort = 'CAATS'
exports.webURL = 'https://aialgo.vercel.app/'